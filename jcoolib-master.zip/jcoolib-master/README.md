jcoolib
=======

A Cartesian coordinate system library for Java Swing
