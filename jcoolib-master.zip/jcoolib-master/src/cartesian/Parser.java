package cartesian;

public class Parser {
}
